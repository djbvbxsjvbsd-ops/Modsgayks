# Valdoria: A Saga do Enzo (Forge 1.20.1 / 47.x / Java 17)

## IntelliJ
File > Open > pasta do projeto > aguarde o Gradle sincronizar (JDK 17) > rode `genIntellijRuns` > `runClient`.

## Compilar pelo celular (GitHub)
1. Crie um repositório no GitHub e envie TODO o conteúdo desta pasta (inclusive `.github/`).
2. Aba **Actions** > workflow **Build Mod** (roda sozinho a cada push; ou "Run workflow").
3. Ao terminar, abra a execução > **Artifacts** > `valdorianrpg-jar` > baixe o .jar.
4. Coloque o .jar na pasta `mods` do Forge 1.20.1.

## Comandos
- `/valdoria quest` mostra a missão atual
- `/valdoria setquest <n>` (op) | `/valdoria boss` (op) | `/valdoria dumpboss` (op)

## Teclas
P = Perfil | M = Mapa | H = HUD | 1/2 = facção (na tela de escolha)
