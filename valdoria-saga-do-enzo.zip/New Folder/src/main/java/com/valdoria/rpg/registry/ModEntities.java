// [ModEntities.java] — SUBSTITUI o original; adiciona entidades glaciais
package com.valdoria.rpg.registry;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.entity.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ValdoriaMod.MODID);
    public static final RegistryObject<EntityType<MalacharEntity>> MALACHAR = ENTITIES.register("malachar",
            () -> EntityType.Builder.<MalacharEntity>of(MalacharEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.1F).fireImmune().clientTrackingRange(10)
                    .build("malachar"));
    public static final RegistryObject<EntityType<CriaturaCongelada>> CRIATURA_CONGELADA = ENTITIES.register("criatura_congelada",
            () -> EntityType.Builder.<CriaturaCongelada>of(CriaturaCongelada::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F).clientTrackingRange(8)
                    .build("criatura_congelada"));
    public static final RegistryObject<EntityType<EsqueletoCongelado>> ESQUELETO_CONGELADO = ENTITIES.register("esqueleto_congelado",
            () -> EntityType.Builder.<EsqueletoCongelado>of(EsqueletoCongelado::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.99F).clientTrackingRange(8)
                    .build("esqueleto_congelado"));
    public static final RegistryObject<EntityType<GuardiaoGlacial>> GUARDIAO_GLACIAL = ENTITIES.register("guardiao_glacial",
            () -> EntityType.Builder.<GuardiaoGlacial>of(GuardiaoGlacial::new, MobCategory.MONSTER)
                    .sized(1.4F, 2.7F).clientTrackingRange(10)
                    .build("guardiao_glacial"));
    public static final RegistryObject<EntityType<SenhorGelo>> SENHOR_GELO = ENTITIES.register("senhor_gelo",
            () -> EntityType.Builder.<SenhorGelo>of(SenhorGelo::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.4F).clientTrackingRange(12)
                    .build("senhor_gelo"));
    public static final RegistryObject<EntityType<EnzoGlacial>> ENZO_GLACIAL = ENTITIES.register("enzo_glacial",
            () -> EntityType.Builder.<EnzoGlacial>of(EnzoGlacial::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.1F).clientTrackingRange(12)
                    .build("enzo_glacial"));
}
