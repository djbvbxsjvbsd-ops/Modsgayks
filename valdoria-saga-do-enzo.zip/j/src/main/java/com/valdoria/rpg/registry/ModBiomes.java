// [ModBiomes.java] src/main/java/com/valdoria/rpg/registry/ModBiomes.java
package com.valdoria.rpg.registry;
import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;
public final class ModBiomes {
    public static final ResourceKey<Biome> NIVERIA = ResourceKey.create(
            Registries.BIOME, new ResourceLocation(ValdoriaMod.MODID, "niveria"));
    private ModBiomes() {}
}
