package com.valdoria.rpg.client.renderer;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.entity.GuiaAldric;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GuiaRenderer extends HumanoidMobRenderer<GuiaAldric, HumanoidModel<GuiaAldric>> {
    private static final ResourceLocation TEX = new ResourceLocation(ValdoriaMod.MODID, "textures/entity/guia_aldric.png");

    public GuiaRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.5F);
    }

    @Override public ResourceLocation getTextureLocation(GuiaAldric e) { return TEX; }
}
