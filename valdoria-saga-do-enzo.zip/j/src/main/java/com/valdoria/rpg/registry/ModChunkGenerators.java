package com.valdoria.rpg.registry;

import com.mojang.serialization.Codec;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.world.NiveriaChunkGenerator;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModChunkGenerators {
    public static final DeferredRegister<Codec<? extends ChunkGenerator>> CHUNK_GENERATORS =
            DeferredRegister.create(Registries.CHUNK_GENERATOR, ValdoriaMod.MODID);
    public static final RegistryObject<Codec<NiveriaChunkGenerator>> NIVERIA =
            CHUNK_GENERATORS.register("niveria", () -> NiveriaChunkGenerator.CODEC);
    private ModChunkGenerators() {}
}
