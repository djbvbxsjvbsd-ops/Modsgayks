package com.valdoria.rpg.network;

import com.valdoria.rpg.data.PlayerData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.NetworkEvent;
import java.util.List;
import java.util.function.Supplier;

/** Ativa o poder Redemoinho de Gelo do Rei Secreto. */
public class WhirlpoolPacket {
    public static void encode(WhirlpoolPacket p, FriendlyByteBuf buf) {}
    public static WhirlpoolPacket decode(FriendlyByteBuf buf) { return new WhirlpoolPacket(); }

    public static void handle(WhirlpoolPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer sp = ctx.get().getSender();
            if (sp == null) return;
            if (PlayerData.getPlayerClass(sp) != PlayerData.CLASS_REI_GELO) return;
            if (PlayerData.getWhirlpoolCooldown(sp) > 0) {
                sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                        "§b❄ Redemoinho em recarga: " + (PlayerData.getWhirlpoolCooldown(sp) / 20) + "s"));
                return;
            }

            // Congela e empurra inimigos num raio de 8 blocos
            AABB box = sp.getBoundingBox().inflate(8.0);
            List<Entity> nearby = sp.level().getEntities(sp, box);
            for (Entity e : nearby) {
                if (!(e instanceof LivingEntity le)) continue;
                if (le == sp) continue;
                // Efeito de gelo + lentidão
                le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2, false, true));
                le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 1, false, true));
                // Knockback radial
                double dx = le.getX() - sp.getX();
                double dz = le.getZ() - sp.getZ();
                double len = Math.sqrt(dx * dx + dz * dz);
                if (len > 0) {
                    le.push(dx / len * 1.5, 0.4, dz / len * 1.5);
                }
                le.hurt(sp.damageSources().playerAttack(sp), 6.0F);
            }

            // Buff ao próprio jogador: resistência temporária ao frio
            sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 0, false, true));
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, 1, false, true));

            PlayerData.setWhirlpoolCooldown(sp, 400); // 20 segundos
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                    "§b❄❄ REDEMOINHO DE GELO ativado! (" + nearby.stream().filter(e -> e instanceof LivingEntity).count() + " inimigos atingidos)"));
            ModNetwork.sync(sp);
        });
        ctx.get().setPacketHandled(true);
    }
}
