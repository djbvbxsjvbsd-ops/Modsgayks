// [ProfileScreen.java] — Interface tecnológica e profissional com sistema de classes
package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.client.KeyMappings;
import com.valdoria.rpg.quest.Quest;
import com.valdoria.rpg.quest.QuestData;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import java.util.Collection;

public class ProfileScreen extends Screen {
    private static final int W = 320, H = 240;
    // Paleta tech-blue
    private static final int C_BG_TOP     = 0xF5050A14;
    private static final int C_BG_BOT     = 0xF5020509;
    private static final int C_BORDER_STD = 0xFF00BFFF;
    private static final int C_BORDER_ICE = 0xFF88EEFF;
    private static final int C_ACCENT     = 0xFF0088CC;
    private static final int C_PANEL      = 0x88071525;
    private static final int C_HEADER_TXT = 0xFF00DFFF;
    private static final int C_LABEL      = 0xFF7EC8E3;
    private static final int C_VALUE      = 0xFFE0F0FF;
    private static final int C_QUEST_BG   = 0x99031020;
    private static final int C_HP         = 0xFFFF4455;
    private static final int C_MANA       = 0xFF3388FF;
    private static final int C_XP         = 0xFF44FF88;
    private static final int C_GOLD       = 0xFFFFD700;
    private static final int C_ICE        = 0xFF88DDFF;

    public ProfileScreen() { super(Component.literal("Perfil")); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x = width / 2 - W / 2, y = height / 2 - H / 2;
        boolean ice = ClientData.inNiveria || ClientData.isIceKing();
        int borderColor = ice ? C_BORDER_ICE : C_BORDER_STD;

        // Fundo principal com gradiente
        g.fillGradient(x, y, x + W, y + H, C_BG_TOP, C_BG_BOT);

        // Borda dupla: externa + interna glow
        g.renderOutline(x, y, W, H, borderColor);
        g.renderOutline(x + 2, y + 2, W - 4, H - 4, 0x44 << 24 | (borderColor & 0x00FFFFFF));

        // Linha de scanlines decorativas (efeito tech)
        for (int i = 0; i < H; i += 6) g.fill(x, y + i, x + W, y + i + 1, 0x08FFFFFF);

        // Header bar
        g.fillGradient(x, y, x + W, y + 22, 0xFF061828, 0xFF030C16);
        g.fill(x, y + 22, x + W, y + 23, borderColor);
        // Título com ícone
        String title = ice ? "§b⚡ SISTEMA RPG — PERFIL ❄" : "§b⚡ SISTEMA RPG — PERFIL";
        g.drawCenteredString(font, title, width / 2, y + 7, C_HEADER_TXT);

        // Tag de versão no canto
        g.drawString(font, "§7v2.0", x + W - 26, y + 7, 0x556688, false);

        LocalPlayer p = minecraft != null ? minecraft.player : null;
        if (p == null) { super.render(g, mx, my, pt); return; }

        // ─── COLUNA ESQUERDA: Avatar ───────────────────────────────────────
        int avatarX = x + 10, avatarY = y + 30;
        g.fillGradient(avatarX, avatarY, avatarX + 70, avatarY + 110, C_PANEL, 0x880A1A2A);
        g.renderOutline(avatarX, avatarY, 70, 110, C_ACCENT);
        // Renderer do personagem
        InventoryScreen.renderEntityInInventoryFollowsMouse(g,
                avatarX + 35, avatarY + 95, 32, (float) mx, (float) my, p);
        // Nome abaixo do avatar
        g.drawCenteredString(font, "§b" + p.getName().getString(), avatarX + 35, avatarY + 100, C_VALUE);

        // Classe com ícone
        String classIcon = switch (ClientData.playerClass) {
            case 1 -> "⚔";  case 2 -> "✦";  case 3 -> "➶";  case 4 -> "❄";
            default -> "◌";
        };
        String classColor = switch (ClientData.playerClass) {
            case 1 -> "§c"; case 2 -> "§d"; case 3 -> "§a"; case 4 -> "§b";
            default -> "§7";
        };
        g.drawCenteredString(font, classColor + classIcon + " " + ClientData.className(),
                avatarX + 35, avatarY + 112, C_VALUE);

        // Facção
        String factionIcon = ClientData.faction == 1 ? "✦" : ClientData.faction == 2 ? "☽" : "?";
        String factionColor = ClientData.faction == 1 ? "§e" : ClientData.faction == 2 ? "§c" : "§7";
        g.drawCenteredString(font, factionColor + factionIcon + " " + ClientData.factionName(),
                avatarX + 35, avatarY + 123, C_VALUE);

        // Dimensão
        String dimColor = ClientData.inNiveria ? "§b" : "§a";
        g.drawCenteredString(font, dimColor + (ClientData.inNiveria ? "❄ Nivéria" : "◉ Overworld"),
                avatarX + 35, avatarY + 134, C_VALUE);

        // ─── COLUNA DIREITA: Status Bars ──────────────────────────────────
        int bx = x + 88, by = y + 28, bw = 136, bh = 9;

        // HP
        drawStatBar(g, bx, by,      bw, bh, p.getHealth() / Math.max(1F, p.getMaxHealth()),
                C_HP, "§c♥ HP", String.format("%.0f / %.0f", p.getHealth(), p.getMaxHealth()));
        // Mana
        drawStatBar(g, bx, by + 14, bw, bh, ClientData.mana / Math.max(1F, ClientData.maxMana),
                C_MANA, "§9✦ Mana", String.format("%.0f / %.0f", ClientData.mana, ClientData.maxMana));
        // XP
        drawStatBar(g, bx, by + 28, bw, bh, p.experienceProgress,
                C_XP, "§a⬆ XP", "Nível " + p.experienceLevel);
        // Fome
        drawStatBar(g, bx, by + 42, bw, bh, p.getFoodData().getFoodLevel() / 20F,
                0xFFFF9900, "§6🍖 Fome", p.getFoodData().getFoodLevel() + " / 20");

        // ─── ATO / MISSÃO ─────────────────────────────────────────────────
        int iy = by + 62;
        g.fillGradient(bx, iy, bx + bw + 92, iy + 18, C_PANEL, 0x88030810);
        g.renderOutline(bx, iy, bw + 92, 18, C_ACCENT);
        g.drawString(font, "§7Ato:", bx + 4, iy + 5, C_LABEL, false);
        g.drawString(font, "§e" + QuestData.actName(ClientData.act()), bx + 24, iy + 5, C_GOLD, false);
        g.drawString(font, "§7Missões: §f" + Math.min(101, ClientData.completed) + " §7/ §f101",
                bx + 4, iy + 24, C_VALUE, false);

        // Progresso geral da saga
        float sagaProg = ClientData.completed / 101F;
        int progW = bw + 92 - 8;
        g.fill(bx + 4, iy + 36, bx + 4 + progW, iy + 43, 0xFF000000);
        g.fillGradient(bx + 4, iy + 36, bx + 4 + (int)(progW * sagaProg), iy + 43, 0xFF00AEFF, 0xFF005E99);
        g.drawString(font, String.format("§7%.0f%%", sagaProg * 100), bx + 4 + progW + 2, iy + 37, C_LABEL, false);

        // Missão atual
        if (ClientData.completed < QuestData.size()) {
            Quest q = QuestData.get(ClientData.completed + 1);
            int qy = iy + 50;
            g.fill(bx, qy, bx + bw + 92, qy + 30, C_QUEST_BG);
            g.renderOutline(bx, qy, bw + 92, 30, borderColor);
            g.drawString(font, "§7▶ " + q.title(), bx + 4, qy + 4, C_HEADER_TXT, false);
            // Trunca objetivo se muito longo
            String obj = q.objective();
            if (obj.length() > 42) obj = obj.substring(0, 39) + "...";
            g.drawString(font, "§7  " + obj, bx + 4, qy + 16, 0xFF88AACC, false);
        } else {
            int qy = iy + 50;
            g.fill(bx, qy, bx + bw + 92, qy + 18, C_QUEST_BG);
            g.drawCenteredString(font, "§6✦ SAGA COMPLETA! ✦", bx + (bw + 92) / 2, qy + 5, C_GOLD);
        }

        // ─── PAINEL INFERIOR: Efeitos + Info de Classe ───────────────────
        int panelX = x + 8, panelY = y + H - 62, panelW = W - 16, panelH = 54;
        g.fillGradient(panelX, panelY, panelX + panelW, panelY + panelH, C_PANEL, 0x88020509);
        g.renderOutline(panelX, panelY, panelW, panelH, C_ACCENT);
        g.fill(panelX, panelY, panelX + panelW, panelY + 1, borderColor);

        // Info de classe especial
        if (ClientData.playerClass == 4) {
            // Rei do Gelo
            String cdText = ClientData.whirlpoolCooldown > 0
                    ? "§7Recarga: §c" + (ClientData.whirlpoolCooldown / 20) + "s"
                    : "§aRedemoinho: §bPRONTO [R]";
            g.drawString(font, "§b❄ Rei do Gelo §7— Debuffs -40%  " + cdText, panelX + 4, panelY + 4, C_ICE, false);
            g.drawString(font, "§7Trocas de classe: §f" + ClientData.classChanges + " §7/ §f2 usadas",
                    panelX + 4, panelY + 14, C_LABEL, false);
        } else {
            g.drawString(font, "§7Trocas de classe: §f" + ClientData.classChanges + " §7/ §f2 usadas",
                    panelX + 4, panelY + 4, C_LABEL, false);
        }

        // Efeitos ativos
        Collection<MobEffectInstance> effects = p.getActiveEffects();
        int ex = panelX + 4, ey = panelY + (ClientData.playerClass == 4 ? 26 : 16);
        if (!effects.isEmpty()) {
            g.drawString(font, "§7Efeitos:", ex, ey, C_LABEL, false);
            ex += 44;
            for (MobEffectInstance ef : effects) {
                String name = ef.getEffect().getDisplayName().getString();
                boolean debuff = ef.getEffect().isBeneficial();
                int col = debuff ? 0xFF88FF88 : 0xFFFF6666;
                g.drawString(font, (debuff ? "§a+" : "§c-") + name.substring(0, Math.min(name.length(), 10)),
                        ex, ey, col, false);
                ex += font.width(name.substring(0, Math.min(name.length(), 10))) + 10;
                if (ex > panelX + panelW - 20) break;
            }
        } else {
            g.drawString(font, "§7Sem efeitos ativos", ex, ey, 0xFF445566, false);
        }

        // Linha separadora inferior
        g.fill(panelX, panelY + panelH - 14, panelX + panelW, panelY + panelH - 13, 0x33FFFFFF);
        if (ClientData.inNiveria) {
            g.drawString(font, "§b❄ Fragmentos: §f" + ClientData.fragmentosGlaciais,
                    panelX + 4, panelY + panelH - 11, C_ICE, false);
        }
        g.drawString(font, "§7[P] Fechar  [C] Classe", panelX + panelW - 100, panelY + panelH - 11, 0xFF334455, false);

        super.render(g, mx, my, pt);
    }

    private void drawStatBar(GuiGraphics g, int x, int y, int w, int h, float frac,
                             int color, String label, String value) {
        frac = Math.max(0F, Math.min(1F, frac));
        // Fundo
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF0A1420);
        // Barra preenchida
        int filled = (int)((w - 2) * frac);
        if (filled > 0) {
            g.fillGradient(x + 1, y + 1, x + 1 + filled, y + h - 1,
                    color, darken(color, 0.6F));
        }
        // Texto label (esquerda)
        g.drawString(font, label, x + w + 4, y + 1, color, false);
        // Valor (sobreposto na barra)
        g.drawString(font, "§f" + value, x + 3, y + 1, 0xFFFFFFFF, false);
    }

    private static int darken(int color, float factor) {
        int r = (int)(((color >> 16) & 0xFF) * factor);
        int g2 = (int)(((color >> 8) & 0xFF) * factor);
        int b = (int)((color & 0xFF) * factor);
        return (color & 0xFF000000) | (r << 16) | (g2 << 8) | b;
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (KeyMappings.PROFILE.matches(key, scan)) { onClose(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override public boolean isPauseScreen() { return false; }
}
