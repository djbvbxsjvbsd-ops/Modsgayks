package com.valdoria.rpg.data;

import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

/** Tudo salvo em persistentData (sobrevive à morte). */
public final class PlayerData {
    public static final float MAX_MANA = 100.0F;

    // Classes disponíveis
    public static final int CLASS_NONE      = 0;
    public static final int CLASS_GUERREIRO = 1;
    public static final int CLASS_MAGO      = 2;
    public static final int CLASS_ARQUEIRO  = 3;
    public static final int CLASS_REI_GELO  = 4; // 40% menos debuffs Nivéria + Redemoinho de Gelo

    private PlayerData() {}

    public static CompoundTag root(Player p) {
        CompoundTag forge = p.getPersistentData();
        if (!forge.contains(Player.PERSISTED_NBT_TAG, 10)) forge.put(Player.PERSISTED_NBT_TAG, new CompoundTag());
        CompoundTag persisted = forge.getCompound(Player.PERSISTED_NBT_TAG);
        if (!persisted.contains(ValdoriaMod.MODID, 10)) persisted.put(ValdoriaMod.MODID, new CompoundTag());
        return persisted.getCompound(ValdoriaMod.MODID);
    }

    public static int getFaction(Player p)          { return root(p).getInt("faction"); }
    public static void setFaction(Player p, int f)  { root(p).putInt("faction", f); }

    public static int getCompleted(Player p)         { return root(p).getInt("completed"); }
    public static void setCompleted(Player p, int n) { root(p).putInt("completed", n); }

    // ===== CLASSE =====
    public static int getPlayerClass(Player p)       { return root(p).getInt("playerClass"); }
    public static void setPlayerClass(Player p, int c) { root(p).putInt("playerClass", c); }

    public static String getClassName(Player p) {
        return switch (getPlayerClass(p)) {
            case CLASS_GUERREIRO -> "Guerreiro";
            case CLASS_MAGO      -> "Mago";
            case CLASS_ARQUEIRO  -> "Arqueiro";
            case CLASS_REI_GELO  -> "Rei Secreto do Gelo";
            default              -> "Sem Classe";
        };
    }

    /** Número de trocas de classe já usadas (máx 2 permitidas). */
    public static int getClassChanges(Player p)      { return root(p).getInt("classChanges"); }
    public static void addClassChange(Player p)      { root(p).putInt("classChanges", getClassChanges(p) + 1); }

    /** Cooldown do Redemoinho de Gelo (Rei Secreto) em ticks. 0 = disponível. */
    public static int getWhirlpoolCooldown(Player p) { return root(p).getInt("whirlpoolCd"); }
    public static void setWhirlpoolCooldown(Player p, int ticks) { root(p).putInt("whirlpoolCd", Math.max(0, ticks)); }
    public static void tickWhirlpool(Player p) {
        int cd = getWhirlpoolCooldown(p);
        if (cd > 0) root(p).putInt("whirlpoolCd", cd - 1);
    }

    // ===== MANA (Mago tem +50% de mana máxima) =====
    public static float getMaxMana(Player p) {
        return getPlayerClass(p) == CLASS_MAGO ? MAX_MANA * 1.5F : MAX_MANA;
    }
    public static float getMana(Player p) {
        CompoundTag t = root(p);
        return t.contains("mana") ? t.getFloat("mana") : MAX_MANA;
    }
    public static void setMana(Player p, float v) {
        root(p).putFloat("mana", Math.max(0.0F, Math.min(getMaxMana(p), v)));
    }
    public static void addMana(Player p, float v) { setMana(p, getMana(p) + v); }

    // ===== KILLS / FLAGS =====
    public static int getKills(Player p, String key) {
        CompoundTag t = root(p);
        return t.contains("kills", 10) ? t.getCompound("kills").getInt(key) : 0;
    }
    public static void addKill(Player p, String key) {
        CompoundTag t = root(p);
        if (!t.contains("kills", 10)) t.put("kills", new CompoundTag());
        CompoundTag k = t.getCompound("kills");
        k.putInt(key, k.getInt(key) + 1);
    }

    public static boolean hasFlag(Player p, String flag) {
        CompoundTag t = root(p);
        return t.contains("flags", 10) && t.getCompound("flags").getBoolean(flag);
    }
    public static void setFlag(Player p, String flag) {
        CompoundTag t = root(p);
        if (!t.contains("flags", 10)) t.put("flags", new CompoundTag());
        t.getCompound("flags").putBoolean(flag, true);
    }
}
