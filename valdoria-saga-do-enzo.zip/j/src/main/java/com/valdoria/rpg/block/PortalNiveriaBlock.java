package com.valdoria.rpg.block;

import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

public class PortalNiveriaBlock extends Block {

    public PortalNiveriaBlock(Properties props) { super(props); }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(entity instanceof ServerPlayer sp)) return;
        if (sp.isOnPortalCooldown()) { sp.setPortalCooldown(); return; }

        boolean emNiveria = sp.level().dimension().equals(NiveriaDimension.NIVERIA);

        if (emNiveria) {
            // ===== PORTAL DE VOLTA — Nivéria → Overworld =====
            ServerLevel overworld = sp.getServer().getLevel(Level.OVERWORLD);
            if (overworld == null) return;

            BlockPos owSpawn = overworld.getSharedSpawnPos();
            int owY = overworld.getHeight(
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    owSpawn.getX(), owSpawn.getZ()) + 1;

            sp.teleportTo(overworld,
                    owSpawn.getX() + 0.5D, owY, owSpawn.getZ() + 0.5D,
                    sp.getYRot(), sp.getXRot());
            sp.setPortalCooldown();
            sp.sendSystemMessage(Component.literal(
                    "§a✦ Você retornou a Valdoria. Boa sorte, Escolhido."));

        } else {
            // ===== PORTAL DE IDA — Overworld → Nivéria =====
            ServerLevel niveria = sp.getServer().getLevel(NiveriaDimension.NIVERIA);
            if (niveria == null) return;

            // garante a sala/estruturas e chega no canto da plataforma (fora do portal de volta)
            com.valdoria.rpg.world.NiveriaStructures.ensureBuilt(niveria);
            sp.teleportTo(niveria,
                    2.5D, com.valdoria.rpg.world.NiveriaChunkGenerator.SPAWN_Y + 0.1D, 2.5D,
                    sp.getYRot(), sp.getXRot());
            sp.setPortalCooldown();
        }
    }
}
