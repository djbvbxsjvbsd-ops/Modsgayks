// [ModBusEvents.java] — SUBSTITUI o original; registra atributos das entidades glaciais
package com.valdoria.rpg.event;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.entity.*;
import com.valdoria.rpg.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModBusEvents {
    @SubscribeEvent
    public static void onEntityAttributes(EntityAttributeCreationEvent e) {
        e.put(ModEntities.MALACHAR.get(), MalacharEntity.createAttributes().build());
        e.put(ModEntities.CRIATURA_CONGELADA.get(), CriaturaCongelada.createAttributes().build());
        e.put(ModEntities.ESQUELETO_CONGELADO.get(), EsqueletoCongelado.createAttributes().build());
        e.put(ModEntities.GUARDIAO_GLACIAL.get(), GuardiaoGlacial.createAttributes().build());
        e.put(ModEntities.SENHOR_GELO.get(), SenhorGelo.createAttributes().build());
        e.put(ModEntities.ENZO_GLACIAL.get(), EnzoGlacial.createAttributes().build());
        e.put(ModEntities.DRAGAO_GELO.get(), DragaoGelo.createAttributes().build());
        e.put(ModEntities.GUIA_ALDRIC.get(), GuiaAldric.createAttributes().build());
    }
}
