package com.valdoria.rpg.network;

import com.valdoria.rpg.client.ClientData;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class SyncDataPacket {
    public final int faction, completed, playerClass, classChanges, whirlpoolCd;
    public final float mana, maxMana;

    public SyncDataPacket(int faction, int completed, float mana, float maxMana,
                          int playerClass, int classChanges, int whirlpoolCd) {
        this.faction = faction; this.completed = completed;
        this.mana = mana; this.maxMana = maxMana;
        this.playerClass = playerClass; this.classChanges = classChanges;
        this.whirlpoolCd = whirlpoolCd;
    }

    public static SyncDataPacket from(ServerPlayer sp) {
        return new SyncDataPacket(
                PlayerData.getFaction(sp), PlayerData.getCompleted(sp),
                PlayerData.getMana(sp), PlayerData.getMaxMana(sp),
                PlayerData.getPlayerClass(sp), PlayerData.getClassChanges(sp),
                PlayerData.getWhirlpoolCooldown(sp));
    }

    public static void encode(SyncDataPacket p, FriendlyByteBuf buf) {
        buf.writeInt(p.faction); buf.writeInt(p.completed);
        buf.writeFloat(p.mana); buf.writeFloat(p.maxMana);
        buf.writeInt(p.playerClass); buf.writeInt(p.classChanges);
        buf.writeInt(p.whirlpoolCd);
    }
    public static SyncDataPacket decode(FriendlyByteBuf buf) {
        return new SyncDataPacket(buf.readInt(), buf.readInt(),
                buf.readFloat(), buf.readFloat(),
                buf.readInt(), buf.readInt(), buf.readInt());
    }
    public static void handle(SyncDataPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ClientData.update(pkt.faction, pkt.completed, pkt.mana, pkt.maxMana);
            ClientData.updateClass(pkt.playerClass, pkt.classChanges, pkt.whirlpoolCd);
        });
        ctx.get().setPacketHandled(true);
    }
}
