package com.valdoria.rpg.network;

import com.valdoria.rpg.client.ClientData;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;

/** Alvos do ESP calculados no servidor: 0=nada 1=mob/boss 2=item 3=local 4=portal. pts = {x,y,z,largura,altura}. */
public class SyncEspPacket {
    public final int kind;
    public final String label;
    public final List<float[]> pts;

    public SyncEspPacket(int kind, String label, List<float[]> pts) {
        this.kind = kind; this.label = label; this.pts = pts;
    }

    public static void encode(SyncEspPacket p, FriendlyByteBuf buf) {
        buf.writeInt(p.kind);
        buf.writeUtf(p.label, 128);
        buf.writeVarInt(p.pts.size());
        for (float[] f : p.pts) for (int i = 0; i < 5; i++) buf.writeFloat(f[i]);
    }

    public static SyncEspPacket decode(FriendlyByteBuf buf) {
        int kind = buf.readInt();
        String label = buf.readUtf(128);
        int n = buf.readVarInt();
        List<float[]> pts = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            float[] f = new float[5];
            for (int j = 0; j < 5; j++) f[j] = buf.readFloat();
            pts.add(f);
        }
        return new SyncEspPacket(kind, label, pts);
    }

    public void handle(NetworkEvent.Context ctx) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientData.updateEsp(kind, label, pts));
    }
}
