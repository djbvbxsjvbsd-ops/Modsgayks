// [SenhorGelo.java]
package com.valdoria.rpg.entity;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
public class SenhorGelo extends WitherSkeleton {
    private final ServerBossEvent bossBar = new ServerBossEvent(
            Component.literal("Senhor do Gelo"), BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.NOTCHED_6);
    public SenhorGelo(EntityType<? extends SenhorGelo> type, Level level) {
        super(type, level);
        this.setCustomName(Component.literal("Senhor do Gelo"));
        this.setPersistenceRequired();
    }
    public static AttributeSupplier.Builder createAttributes() {
        return WitherSkeleton.createAttributes()
                .add(Attributes.MAX_HEALTH, 200.0D)
                .add(Attributes.ATTACK_DAMAGE, 14.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.ARMOR, 8.0D);
    }
    @Override
    public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossBar.addPlayer(p); }
    @Override
    public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossBar.removePlayer(p); }
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossBar.setProgress(getHealth() / getMaxHealth());
        if (tickCount % 60 == 0) {
            for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(8.0D))) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 2));
                p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
            }
        }
    }
    @Override
    public void die(DamageSource src) {
        super.die(src);
        if (level() instanceof ServerLevel sl) {
            for (ServerPlayer p : sl.players()) {
                if (p.distanceToSqr(this) < 100.0D * 100.0D) {
                    PlayerData.setFlag(p, "senhor_gelo_dead");
                }
            }
        }
        bossBar.removeAllPlayers();
    }
}
