# ValdorianRPG — Mod Completo v2.0

Mod RPG narrativo para Minecraft 1.20.x (Forge). A saga de Enzo em dois mundos: Valdoria e Nivéria.

## ⚙️ Compilar (GitHub Actions)
Push para `main` → o workflow `build.yml` compila e gera o `.jar` em `build/libs/`.

## 🎮 Teclas de Atalho
| Tecla | Função |
|-------|--------|
| P | Tela de Perfil (tech UI) |
| M | Mapa de Valdoria/Nivéria |
| H | Alternar HUD |
| C | Tela de Classe |
| R | Redemoinho de Gelo (Rei Secreto) |

## 📖 Sistema de Quests — 101 Missões em 10 Atos
- **Ato I–V:** Overworld — Construção do castelo, escolha de facção, batalha contra Malachar
- **Ato VI–X:** Nivéria — Mundo congelado, templos, castelo glacial, Enzo Glacial final

## ⚔️ Sistema de Classes (4 classes)
Escolha inicial livre, depois 2 trocas disponíveis ao longo da saga.
| Classe | Bônus | Desbloqueio |
|--------|-------|-------------|
| Guerreiro | HP regen passivo em combate | Início |
| Mago | Mana +50%, Dano +10% | Início |
| Arqueiro | Velocidade +10%, menos fome | Início |
| **Rei Secreto do Gelo** | **Debuffs Nivéria -40% + Redemoinho de Gelo [R]** | **Quest 70** |

## 🌊 Poder: Redemoinho de Gelo (Rei do Gelo)
- Raio de 8 blocos
- Lentidão + Fraqueza nos inimigos por 4s
- Knockback radial + 6 de dano
- Buff de Resistência e Velocidade ao jogador
- Cooldown: 20 segundos

## 🌍 Dimensões
- **Overworld (Valdoria):** mundo principal, castelo progressivo
- **Nivéria:** dimensão de gelo com debuffs (lentidão + fraqueza). Rei do Gelo sofre 40% menos

## 👾 Entidades
- Malachar (boss Ato V), Criatura Congelada, Esqueleto Congelado
- Guardião Glacial, Senhor do Gelo, Enzo Glacial (boss final), Dragão do Gelo

## 🎒 Itens
- Armadura e Espada Definitivas (Valdoria), Armadura Glacial completa
- Espada Glacial, Cristal Glacial, Fragmento Glacial, Coração de Nivéria
- Coroa de Nivéria, Chave Glacial, Chave Real, Essência do Guardião, Pedra de Fundação

## 🏰 Mecânicas Especiais
- Castelo progressivo (10 estágios conforme missões completadas)
- Facções: Anjo (mana+) ou Demônio (dano+)
- Debuffs de Nivéria: lentidão, fraqueza e fome aumentada
- Hordas noturnas escalonáveis
- Mana com regen passiva (bônus por facção e classe)
- Sistema de flags persistentes (sobrevivem à morte)

## ⚠️ Limitações Conhecidas
- **Flags de quest:** os gatilhos (raio ao redor de estruturas, tempo passado em Nivéria etc.) são estimativas — podem precisar de ajuste conforme o design final das missões.
- **Estruturas em coordenada fixa:** castelo e construções de Nivéria surgem em (0, 0); em terreno irregular podem ficar parcialmente enterradas ou elevadas, e o ponto de spawn em Nivéria pode nascer longe delas.
- **Sem portal de retorno:** ainda não existe bloco de portal de volta para o Overworld; use o comando `/valdoria back` para sair de Nivéria.
